/*
 * FibonacciFun.h
 *
 *  Created on: 2017��4��27��
 *      Author: Administrator
 */

#ifndef FIBONACCIFUN_H_
#define FIBONACCIFUN_H_

int Fibnacci();

#endif /* FIBONACCIFUN_H_ */
