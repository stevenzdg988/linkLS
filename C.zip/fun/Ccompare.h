/*
 * compare.h
 *
 *  Created on: 2017��5��22��
 *      Author: Administrator
 */

#ifndef CCOMPARE_H_
#define CCOMPARE_H_

int outputre();
void caculateA();

#endif /* CCOMPARE_H_ */
